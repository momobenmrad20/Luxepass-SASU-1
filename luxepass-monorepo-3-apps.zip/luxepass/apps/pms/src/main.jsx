import React from "react";
import ReactDOM from "react-dom/client";
import PmsApp from "./App.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <PmsApp />
  </React.StrictMode>
);
